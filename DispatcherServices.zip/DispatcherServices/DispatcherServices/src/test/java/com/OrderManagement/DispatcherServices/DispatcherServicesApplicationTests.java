package com.OrderManagement.DispatcherServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DispatcherServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
